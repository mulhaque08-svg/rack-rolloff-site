# RackRolloff Production Node.js Backend API

Dedicated backend API service for **RackRolloff Dumpster Rentals** (`rackrolloff.com`).

---

## 🛠️ Endpoints:

- **`GET /health`**: Health check status.
- **`POST /api/contact`**: Receives custom quote form submissions and sends HTML emails via SendGrid to `info@rackrolloff.com`.
- **`POST /api/booking`**: Receives dumpster rental orders and sends HTML dispatch receipts via SendGrid to `info@rackrolloff.com`.

---

## 🚀 How to Deploy on DigitalOcean (3-Minute Setup):

1. Go to **DigitalOcean** -> **Apps** -> Click **Create App**.
2. Select your GitHub repository (`mulhaque08-svg/rack-rolloff-site`).
3. Set **Source Directory**: `backend` (or add a **Web Service** component with root directory `/backend`).
4. Set **Environment Variables**:
   - `SENDGRID_API_KEY`: `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`
   - `TO_EMAIL`: `info@rackrolloff.com`
   - `FROM_EMAIL`: `info@rackrolloff.com`
5. Click **Deploy**!

DigitalOcean will assign a live URL like `https://rack-rolloff-backend-xyz.ondigitalocean.app`!
