require('dotenv').config();
const express = require('express');
const cors = require('cors');
const sgMail = require('@sendgrid/mail');

const app = express();
const PORT = process.env.PORT || 8080;

// Configure SendGrid API Key
const SENDGRID_API_KEY = process.env.SENDGRID_API_KEY || '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';
sgMail.setApiKey(SENDGRID_API_KEY);

const TO_EMAIL = process.env.TO_EMAIL || 'info@rackrolloff.com';
const FROM_EMAIL = process.env.FROM_EMAIL || 'info@rackrolloff.com';

app.use(cors());
app.use(express.json());

// Health Check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'RackRolloff Production Backend API', timestamp: new Date() });
});

// Contact Form Endpoint
app.post('/api/contact', async (req, res) => {
  try {
    const { name, email, phone, projectType, zip, message } = req.body;
    
    const msg = {
      to: TO_EMAIL,
      from: FROM_EMAIL,
      subject: `NEW INQUIRY: ${name} (${zip}) - RackRolloff`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; padding: 20px; border: 1px solid #e0e0e0; border-radius: 8px;">
          <h2 style="color: #0d47a1; margin-top: 0;">New Quote Inquiry - RackRolloff</h2>
          <table style="width: 100%; border-collapse: collapse;">
            <tr><td style="padding: 8px; font-weight: bold;">Customer Name:</td><td style="padding: 8px;">${name || 'N/A'}</td></tr>
            <tr><td style="padding: 8px; font-weight: bold;">Email:</td><td style="padding: 8px;"><a href="mailto:${email}">${email || 'N/A'}</a></td></tr>
            <tr><td style="padding: 8px; font-weight: bold;">Phone:</td><td style="padding: 8px;"><a href="tel:${phone}">${phone || 'N/A'}</a></td></tr>
            <tr><td style="padding: 8px; font-weight: bold;">Project Type:</td><td style="padding: 8px;">${projectType || 'General'}</td></tr>
            <tr><td style="padding: 8px; font-weight: bold;">Zip Code:</td><td style="padding: 8px;">${zip || 'N/A'}</td></tr>
          </table>
          <h3 style="color: #333; margin-top: 15px;">Customer Message:</h3>
          <blockquote style="background: #f9f9f9; padding: 12px; border-left: 4px solid #0d47a1; margin: 0;">
            ${message || 'No additional message provided.'}
          </blockquote>
          <hr style="border: none; border-top: 1px solid #eee; margin-top: 20px;">
          <p style="font-size: 0.8rem; color: #888;">RackRolloff Backend Express Service</p>
        </div>
      `
    };

    await sgMail.send(msg);
    console.log(`[BACKEND] Contact inquiry email sent for ${name}`);
    res.json({ success: true, message: 'Inquiry email sent successfully!' });
  } catch (error) {
    console.error('[BACKEND ERROR] Contact email failed:', error.response ? error.response.body : error.message);
    res.status(500).json({ success: false, error: 'Failed to send inquiry email' });
  }
});

// Dumpster Booking Order Endpoint
app.post('/api/booking', async (req, res) => {
  try {
    const { orderId, name, email, phone, address, zipCode, size, wasteType, deliveryDate, duration, paymentMethod, totalCost } = req.body;
    
    const msg = {
      to: TO_EMAIL,
      from: FROM_EMAIL,
      subject: `NEW ORDER #${orderId}: ${size} Dumpster - ${name}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; padding: 20px; border: 1px solid #e0e0e0; border-radius: 8px;">
          <h2 style="color: #0d47a1; margin-top: 0;">New Dumpster Booking Order #${orderId}</h2>
          <table style="width: 100%; border-collapse: collapse; margin-bottom: 15px;">
            <tr style="background: #f4f6f8;"><td style="padding: 8px; font-weight: bold;">Container Size:</td><td style="padding: 8px; color: #0d47a1; font-weight: bold;">${size} Roll-Off</td></tr>
            <tr><td style="padding: 8px; font-weight: bold;">Customer Name:</td><td style="padding: 8px;">${name}</td></tr>
            <tr><td style="padding: 8px; font-weight: bold;">Email:</td><td style="padding: 8px;"><a href="mailto:${email}">${email}</a></td></tr>
            <tr><td style="padding: 8px; font-weight: bold;">Phone:</td><td style="padding: 8px;"><a href="tel:${phone}">${phone}</a></td></tr>
            <tr><td style="padding: 8px; font-weight: bold;">Delivery Address:</td><td style="padding: 8px;">${address}, TX ${zipCode}</td></tr>
            <tr><td style="padding: 8px; font-weight: bold;">Waste Category:</td><td style="padding: 8px;">${wasteType}</td></tr>
            <tr><td style="padding: 8px; font-weight: bold;">Delivery Date:</td><td style="padding: 8px;">${deliveryDate}</td></tr>
            <tr><td style="padding: 8px; font-weight: bold;">Rental Duration:</td><td style="padding: 8px;">${duration} Days</td></tr>
            <tr style="background: #e8f5e9;"><td style="padding: 8px; font-weight: bold;">Total Paid:</td><td style="padding: 8px; color: #2e7d32; font-weight: bold;">$${totalCost} (${paymentMethod})</td></tr>
          </table>
          <hr style="border: none; border-top: 1px solid #eee; margin-top: 20px;">
          <p style="font-size: 0.8rem; color: #888;">RackRolloff Dispatch System</p>
        </div>
      `
    };

    await sgMail.send(msg);
    console.log(`[BACKEND] Booking order email sent for Order #${orderId}`);
    res.json({ success: true, message: 'Order booking email sent successfully!' });
  } catch (error) {
    console.error('[BACKEND ERROR] Booking email failed:', error.response ? error.response.body : error.message);
    res.status(500).json({ success: false, error: 'Failed to send booking email' });
  }
});

app.listen(PORT, () => {
  console.log(`RackRolloff Backend API server listening on port ${PORT}`);
});
